<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'ZE.v=*V%3o~ub&U@Z,s*#TpZ{4hIlso`KEcFjh.,H4YjRTMS>}CqSjr0Hxh{EzGE' );
define( 'SECURE_AUTH_KEY',   'rbP_4`?mQ[O !C*%x?=IDXU$yEACro]!J@%QOi{ebbtU,-w`Y>t)5d16$AE1ZgJN' );
define( 'LOGGED_IN_KEY',     '0w7Q<WQc L=l2xhDy3f=:-&kToY^#(1> ZRa|V>MkXaOFPgZ<(:aE]HfP$RD3CCq' );
define( 'NONCE_KEY',         'ey.WXq,Ju7sPkxYq}9&X*w*c[)Awh~;&dw%NS48GC5DmFmXP4{^VofbS,XG$ya$U' );
define( 'AUTH_SALT',         'joUFRxLz)EqmsrS&g2$0+~mHbUb2&98{BSF]iZVL2X&%DmR(?!>dv_;?mp[~WMmZ' );
define( 'SECURE_AUTH_SALT',  '$=5f%o>mus+z1npX3g^!An|ytd{8*#,,$S/z<y9TsSx&~*L4|O~Lf52`-r.F%BAu' );
define( 'LOGGED_IN_SALT',    's`A,<Fo-/K$Q;Pr}/q++P>JeQm(x<G-G-X5`!F#EcB`X&2SGZqLt9#*?_b:)!1EM' );
define( 'NONCE_SALT',        '<MIxP~FzskHZcs)5xw]y$JJ|CD4RqiX/s1ER] i.cMG5{I-_}Fd9Tm!5ffbHp>|I' );
define( 'WP_CACHE_KEY_SALT', 'W1|r}pGkU4]_WRX|u-_mN>tP2c,Y$$e~Yj#u(?!U!5<OKAYbe8Wj6Fepi.^Udz/]' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
